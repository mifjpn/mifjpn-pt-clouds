#version 120
#define FSH
#define END
#include "/program/deferred2.glsl"
